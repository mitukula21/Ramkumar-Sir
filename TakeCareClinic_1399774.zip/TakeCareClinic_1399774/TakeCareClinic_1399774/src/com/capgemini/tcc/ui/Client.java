package com.capgemini.tcc.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.PatientServiceImpl;
import com.capgemini.tcc.service.IPatientService;

public class Client {

	static Scanner sc = new Scanner(System.in);
	static IPatientService patientService = null;
	static PatientServiceImpl patientServiceImpl = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		PatientBean patientBean = null;

		String pid = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   Take Care Clinic ");
			System.out.println("_________________________\n");
			System.out.println("Welcome To TakeCare Clinic");
			System.out.println("1.Add patient ");
			System.out.println("2.View patient details");
			System.out.println("3.Exit the clinic");
			System.out.println("_____________________________\n");
			System.out.println("Please Select Anyone from the above Options:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (patientBean == null) {
						patientBean = populateDonorBean();
						
					}

					try {
						patientService = new PatientServiceImpl();
						pid = patientService.addPatientDetails(patientBean);

						System.out.println("Patient details  has been successfully registered ");
						System.out.println("patient  ID Is: " + pid);

					} catch (PatientException donorException) {
						logger.error("exception occured", donorException);
						System.err.println("ERROR : "+ donorException.getMessage());
					} finally {
						pid = null;
						patientService = null;
						patientBean = null;
					}

					break;

				case 2:

					patientServiceImpl = new PatientServiceImpl();

					System.out.println("Enter numeric patient id:");
					pid = sc.next();

					while (true) {
						if (patientServiceImpl.validatePatientId(pid)) {
							break;
						} else {
							System.err
									.println("Please enter numeric donor id only, try again");
							pid = sc.next();
						}
					}

					patientBean = getDonorDetails(pid);

					if (patientBean != null) {
						System.out.println("Name             :"
								+ patientBean.getPname());
						System.out.println("Description      :"
								+ patientBean.getPdesc());
						System.out.println("Phone Number     :"
								+ patientBean.getPno());
						System.out.println("Consultation Date:"
								+ patientBean.getPdate());
						System.out.println("age is           :"
								+ patientBean.getAge());
					} else {
						System.err
								.println("There are no Patient details associated with patient id "
										+ pid);
					}

					break;

				

				case 3:

					System.out.print("Exit Take Care clinic Software Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-3]");
				}// end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try

	/*
	 * This function will call the service layer method and return the bean
	 * object which is populated by the information of the given patientId in
	 * parameter
	 */
	private static PatientBean getDonorDetails(String donorId) {
		PatientBean donorBean = null;
		patientService = new PatientServiceImpl();

		try {
			donorBean = patientService.viewPatientDetails(donorId);
		} catch (PatientException donarException) {
			logger.error("exception occured ", donarException);
			System.out.println("ERROR : " + donarException.getMessage());
		}

		patientService = null;
		return donorBean;
	}

	/*
	 * This function will be called by main and will return a validated bean
	 * object OR null if details are invalid
	 */
	private static PatientBean populateDonorBean() {

		// Reading and setting the values for the PatientBean
		
		PatientBean donorBean = new PatientBean();

		System.out.println("\n Enter Details");

		System.out.println("Enter the name of patient: ");
		donorBean.setPname(sc.next());

		System.out.println("Enter patient contact number : ");
		donorBean.setPno(sc.next());

		System.out.println("Enter Patient description: ");
		donorBean.setPdesc(sc.next());

		System.out.println("Enter patient age : ");

		try {
			donorBean.setAge(sc.nextInt());
		} catch (InputMismatchException inputMismatchException) {
			sc.nextLine();
			System.err.println("Please enter a numeric value for age amount, try again");
			}

		patientServiceImpl = new PatientServiceImpl();

		try {
			patientServiceImpl.validatePatient(donorBean);
			return donorBean;
		} catch (PatientException donorException) {
			logger.error("exception occured", donorException);
			System.err.println("Invalid data:");
			System.err.println(donorException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
}
