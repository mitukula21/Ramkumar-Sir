package com.capgemini.tcc.service;

import java.util.List;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;

public interface IPatientService 
{
	public String addPatientDetails(PatientBean donor) throws PatientException;
	public PatientBean viewPatientDetails(String donorId) throws PatientException;
	
}
