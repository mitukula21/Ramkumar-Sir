#please execute the below sql queries for execution

//For creating table

CREATE TABLE patient(patient_id number(10)primary key,
patient_name VARCHAR2(20),
age NUMBER(3),
phone VARCHAR2(10),
description VARCHAR2(80),
consultation_date DATE);

//For sequence
 
CREATE SEQUENCE patient_id_seq START WITH 1000;
 
 
  